
"use strict";

let AnkerDataType = require('./AnkerDataType.js');

module.exports = {
  AnkerDataType: AnkerDataType,
};
